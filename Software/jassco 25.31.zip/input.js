include ("io.asc")
console.log ("0) literal")
var tex1="1) initial asg."
console.log (tex1)
var tex2=""
tex2="2) second asg."
console.log (tex2)
tex2=tex1
console.log ("3) var2var asg.: ", tex2)

var num1=1
var cars = ["Saab", "Volvo", "BMW"];
console.log ("array pos. lit (Saab): ", cars[0])
console.log ("array pos. var (Volvo): ",cars[num1])

console.log ("Array print")
for (num1=0; num1<=2; num1=num1+1) {
	console.log ("Position ", num1, ": ", cars[num1])
}

console.log ("Comparison (different)")
tex1="adix"
tex2="adio"
if (tex1==tex2) {
	console.log ("same!")
}
else {
	console.log ("different!")
}