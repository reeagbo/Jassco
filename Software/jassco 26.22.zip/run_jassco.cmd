@echo off
setlocal

set "PYTHON_EXE=C:\Users\Alex\AppData\Local\Python\pythoncore-3.14-64\python.exe"
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

set "INPUT_FILE=%~1"
set "OUTPUT_FILE=%~2"

if "%INPUT_FILE%"=="" set "INPUT_FILE=input.js"
if "%OUTPUT_FILE%"=="" set "OUTPUT_FILE=output.asm"

"%PYTHON_EXE%" "main.py" "%INPUT_FILE%" "%OUTPUT_FILE%"
