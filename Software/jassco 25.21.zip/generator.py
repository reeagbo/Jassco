import random

RANKS = list(range(2, 15))  # 2 to 14
SCALE = 100

def scale_hand(hand):
    return [r * SCALE for r in sorted(hand)]

def one_hot(index, length=9):
    return [1 if i == index else 0 for i in range(length)]

def generate_sample(category):
    if category == 0:  # High Card
        hand = random.sample(RANKS, 5)
        while len(set(hand)) < 5 or is_straight(hand):
            hand = random.sample(RANKS, 5)
        return scale_hand(hand), one_hot(0)

    elif category == 1:  # Pair
        pair = random.choice(RANKS)
        others = random.sample([r for r in RANKS if r != pair], 3)
        hand = [pair, pair] + others
        return scale_hand(hand), one_hot(1)

    elif category == 2:  # Two Pair
        pairs = random.sample(RANKS, 2)
        other = random.choice([r for r in RANKS if r not in pairs])
        hand = [pairs[0]] * 2 + [pairs[1]] * 2 + [other]
        return scale_hand(hand), one_hot(2)

    elif category == 3:  # Three of a Kind
        triple = random.choice(RANKS)
        others = random.sample([r for r in RANKS if r != triple], 2)
        hand = [triple] * 3 + others
        return scale_hand(hand), one_hot(3)

    elif category == 4:  # Straight
        start = random.choice(range(2, 11))  # Straight starting points
        hand = list(range(start, start + 5))
        return scale_hand(hand), one_hot(4)

    elif category == 5:  # Full House
        triple = random.choice(RANKS)
        pair = random.choice([r for r in RANKS if r != triple])
        hand = [triple] * 3 + [pair] * 2
        return scale_hand(hand), one_hot(5)

    elif category == 6:  # Four of a Kind
        quad = random.choice(RANKS)
        other = random.choice([r for r in RANKS if r != quad])
        hand = [quad] * 4 + [other]
        return scale_hand(hand), one_hot(6)

    elif category == 7:  # Five of a Kind (synthetic)
        rank = random.choice(RANKS)
        hand = [rank] * 5
        return scale_hand(hand), one_hot(7)

    elif category == 8:  # Junk
        hand = [random.choice(RANKS)] * 5
        return scale_hand(hand), one_hot(8)

    return None

def is_straight(hand):
    s = sorted(set(hand))
    return len(s) == 5 and max(s) - min(s) == 4

def generate_dataset(n_per_class=20):
    dataset = []
    for category in range(9):
        for _ in range(n_per_class):
            input_, target = generate_sample(category)
            dataset.append((input_, target))
    random.shuffle(dataset)
    return dataset

# Example: Generate 180 samples (20 per class)
if __name__ == "__main__":
    samples = generate_dataset(n_per_class=100)
    for input_, target in samples:
        print(f"({input_}, {target}),")
