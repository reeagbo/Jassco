import random

# Constants
input_size = 5
hidden_size = 10
output_size = 9
random.seed(42)

def init_matrix(rows, cols):
    # Initialize weights with small random integers
    return [[random.randint(-50, 50) for _ in range(cols)] for _ in range(rows)]

def init_vector(size):
    return [0] * size

def relu(x):
    return max(0, x)

def leaky_relu(x):
    return x if x > 0 else x // 1000  # small negative slope (~0.1)
    #return x if x > 0 else 1  # small negative slope (~0.1)


def sse_loss(predicted, expected):
    sse = 0
    for p, e in zip(predicted, expected):
        diff = e - p
        sse += diff * diff
    return sse

def mae_loss(predicted, expected):
    total_error = 0
    for p, e in zip(predicted, expected):
        diff = abs(e - p)
        total_error += diff
    return total_error

def forward_pass(x):
    # Compute hidden layer activations
    hidden = []
    #print("\nHidden Layer...")
    for i in range(len(weights1)):
        accumulated_output = 0
        for j in range(len(x)):
            accumulated_output += weights1[i][j] * x[j]
            #print ("Weight#", i, j , "= ", weights1[i][j], ", Input=", x[j], ", Accumulated=", accumulated_output)
            
        accumulated_output = accumulated_output // scale 
        accumulated_output+= bias1[i]                
        accumulated_output= leaky_relu(accumulated_output)
        hidden.append(accumulated_output)       
        #print ("Accumulated:", accumulated_output)
    #print ("Hidden result:", hidden)

    # Compute output layer activations
    #print("\nOutput Layer...")

    output = []
    for i in range(len(weights2)):
        accumulated_output = 0
        for j in range(len(hidden)):
            accumulated_output += weights2[i][j] * hidden[j] #// scale # !!!
            #print ("Weight#", i, j , "= ", weights2[i][j], ", Input=", hidden[j], ", Accumulated=", accumulated_output)

        accumulated_output = accumulated_output // scale # !!!
        accumulated_output += bias2[i]
        output.append(accumulated_output)       
        #print ("Accumulated:", accumulated_output)
    #print ("Output result:", output)

    return output, hidden

def update_output_layer():
    #print("Output L, original weights:")
    #for row in weights2:
    #    print(row)
        
    for k in range(len(weights2)): # for every output neuron...
        error = target[k] - predicted[k]
        #print ("Output Layer: neuron", k , ", Error:", error)

        bias2[k] += (learning_rate * error) // (100 * scale)
        #print ("Bias delta =", round ((learning_rate / 100) * (error / scale)), "New Bias:", bias2[k])
        
        for j in range(len(hidden)): 
            delta = (learning_rate * error * hidden[j]) // (scale * scale * 100)
            weights2[k][j] += delta
            #print ("Weight [", j ,k, "] Delta  =", delta, ", updated weight=", weights2[k][j])
            #print ("Debug:", error * hidden[j])

    #print ("Output L, updated weights")
    #for row in weights2:
    #    print(row)
        
def update_hidden_layer(x):
    #print("Hidden L, original weights:")
    #for row in weights1:
    #    print(row)
    
    # delta_output is list of output layer deltas (target - predicted)
    for j in range(len(hidden)):
        #print ("Hidden Layer: neuron", j)
        
        # Compute delta_j for hidden neuron j
        delta_j = 0
        for k in range(len(output_delta)):
            #delta_j += round((learning_rate / 100) * (delta_output[k] / scale) * (weights2[k][j] / scale))
            delta_j += (learning_rate * output_delta[k] * weights2[k][j]) // (scale * scale * 100)

        # Apply ReLU derivative: zero if hidden neuron output is zero
        if hidden[j] == 0:
            delta_j = 0

        # Scale delta_j down to match input scale
        #delta_j = delta_j // scale

        # Update bias for hidden neuron j
        #bias1[j] += round((learning_rate / 100) * (delta_j / scale))
        bias1[j] += delta_j

        # Update weights for hidden neuron j
        for i in range(len(x)):
            #delta_w = round((learning_rate / 100) * (delta_j /scale) * (x[i]/scale))
            delta_w = (learning_rate * delta_j * x[i]) // (scale * scale * 100)
            weights1[j][i] += delta_w
            #print ("Weight [", j ,i, "] Delta  =", delta_w, ", updated weight=", weights1[j][i])

    #print ("Hidden layer, updated weights:", weights1[j])
    #print("Hidden L, updated weights:")
    #for row in weights1:
    #    print(row)
        
        
samples = [
# pairs
    ([200, 200, 500, 700, 900], [0, 100, 0, 0, 0, 0, 0, 0, 0]),   # Pair of 2s
    ([300, 300, 500, 700, 900], [0, 100, 0, 0, 0, 0, 0, 0, 0]),   # Pair of 3s
    ([400, 400, 500, 700, 900], [0, 100, 0, 0, 0, 0, 0, 0, 0]),   # Pair of 4s
    ([500, 500, 600, 800, 900], [0, 100, 0, 0, 0, 0, 0, 0, 0]),   # Pair of 5s
    ([600, 600, 700, 800, 900], [0, 100, 0, 0, 0, 0, 0, 0, 0]),   # Pair of 6s
    ([700, 700, 800, 900, 1000], [0, 100, 0, 0, 0, 0, 0, 0, 0]),  # Pair of 7s
    ([800, 800, 900, 1000, 1100], [0, 100, 0, 0, 0, 0, 0, 0, 0]), # Pair of 8s
    ([900, 900, 1000, 1100, 1200], [0, 100, 0, 0, 0, 0, 0, 0, 0]),# Pair of 9s
    ([1000, 1000, 1100, 1200, 1300], [0, 100, 0, 0, 0, 0, 0, 0, 0]), # Pair of 10s
    ([1100, 1100, 1200, 1300, 1400], [0, 100, 0, 0, 0, 0, 0, 0, 0]), # Pair of Jacks (11s)
    ([1200, 1200, 1300, 1400, 1400], [0, 100, 0, 0, 0, 0, 0, 0, 0]), # Pair of Queens (12s)
    ([1300, 1300, 1400, 1400, 1400], [0, 100, 0, 0, 0, 0, 0, 0, 0]), # Pair of Kings (13s)
    ([1400, 1400, 900, 800, 700], [0, 100, 0, 0, 0, 0, 0, 0, 0]),  # Pair of Aces (14s)
    
    ([500, 700, 500, 800, 900], [0, 100, 0, 0, 0, 0, 0, 0, 0]),   # Pair of 5s
    ([700, 600, 900, 600, 1000], [0, 100, 0, 0, 0, 0, 0, 0, 0]),  # Pair of 6s
    ([800, 1100, 1000, 700, 700], [0, 100, 0, 0, 0, 0, 0, 0, 0]), # Pair of 7s
    ([900, 1200, 1100, 800, 800], [0, 100, 0, 0, 0, 0, 0, 0, 0]), # Pair of 8s
    ([1000, 900, 1300, 900, 1100], [0, 100, 0, 0, 0, 0, 0, 0, 0]),# Pair of 9s
    ([1100, 1400, 1000, 1100, 900], [0, 100, 0, 0, 0, 0, 0, 0, 0]),# Pair of 10s
    ([1300, 1100, 1200, 1100, 1400], [0, 100, 0, 0, 0, 0, 0, 0, 0]),# Pair of Jacks (11s)
    ([1200, 1400, 1300, 1300, 1100], [0, 100, 0, 0, 0, 0, 0, 0, 0]),# Pair of Queens (12s)
    ([1400, 900, 1300, 1400, 1200], [0, 100, 0, 0, 0, 0, 0, 0, 0]),# Pair of Kings (13s)
    ([1400, 1100, 1000, 1400, 1200], [0, 100, 0, 0, 0, 0, 0, 0, 0]),# Pair of Aces (14s)

]

test_set=[
    [2,2,4,8,9],   # Pair of 3s
    [3,3,3,5,7], # Pair of Queens
    
    [5, 3, 6, 3, 8],   # Pair of 3s
    [12, 4, 7, 9, 12], # Pair of Queens
    [2, 10, 5, 5, 11], # Pair of 5s
    [9, 8, 14, 6, 8],  # Pair of 8s
    [7, 13, 2, 7, 4],  # Pair of 7s
    
    [7, 13, 2, 10, 4],  # Pair of 7s

 #   [4, 4, 4, 9, 10],   # Trio of 4s
 #   [12, 5, 12, 12, 7], # Trio of Queens (12s)
 #   [9, 6, 9, 9, 3],    # Trio of 9s
 #   [13, 13, 2, 13, 6], # Trio of Kings (13s)
 #   [8, 8, 1, 5, 8],    # Trio of 8s
]

# Initialize weights and biases
weights1 = init_matrix(hidden_size, input_size)
bias1 = init_vector(hidden_size)
weights2 = init_matrix(output_size, hidden_size)
bias2 = init_vector(output_size)

# learning rate controller
#sse_gain_list = []
#gain_window = 5         # How many recent gains to consider
#gain_threshold_up = 0.001   # Average gain above this → increase LR
#gain_threshold_down = 0.0001  # Below this → decrease LR
#lr_increase_factor = 1.1     # Increase LR by 10%
#lr_decrease_factor = 0.5     # Decrease LR by 50%
#min_lr = 1
#max_lr = 100

# main parameters
scale = 100
learning_rate = 70
epoch_total = 10
epoch_number = 0
loss_min= 1000000

# Print network info
print("Epoch 0")
print("Network initial information")
print("weights1[0]:", weights1[0])
print("bias1:", bias1)
print("weights2[0]:", weights2[0])
print("bias2:", bias2)
print("")

for epoch in range (epoch_total):
    epoch_number+=1
    print ("\n-------------------------------------------------------------------")
    print ("Epoch", epoch_number)

    for inputs, target in samples:
        print ("\n-------------------------------------------------------------------\n")
        #print ("Epoch", epoch_number)
        print("Input                 :", inputs)
        print("Target                :", target)
        print("")
        
        #print("1) Running network...")
        predicted, hidden = forward_pass(inputs)
        loss_before = sse_loss(predicted, target)
        output_delta = [target[k] - predicted[k] for k in range(len(target))]
        print("Network output before :", predicted)
        print("Output delta before BP:", output_delta)
        print("SSE before BP         :", loss_before)
        
        #print("\n2) Back-propagation...")

        #print("\nUpdating Output Layer...")
        update_output_layer()
        
        #print("\nUpdating Hidden Layer...")
        update_hidden_layer(inputs)
        
        #print("\n3) Running network after update...")
        predicted_after, _ = forward_pass(inputs)
        loss_after = sse_loss(predicted_after, target)
        print("Network output after  :", predicted_after)
        print("SSE after BP          :", loss_after)
        sse_gain= loss_before - loss_after
        #sse_gain_list.append(sse_gain)
        print("SSE gain              :", sse_gain)
                
    # monitoring
    if abs(loss_after) < abs(loss_min):
        loss_min= loss_after
        epoch_min=epoch_number
        
    # learning rate controller
    #if len(sse_gain_list) >= gain_window:
    #    recent_gains = sse_gain_list[-gain_window:]
    #    avg_gain = sum(recent_gains) / gain_window
    #
    #    if avg_gain > gain_threshold_up:
    #        learning_rate = min(learning_rate * lr_increase_factor, max_lr)
    #    elif avg_gain < gain_threshold_down:
    #        learning_rate = max(learning_rate * lr_decrease_factor, min_lr)           
    #    print(f"SSE gain (average)    : {avg_gain:.1f}, learning rate: {learning_rate:.1f}")
print ("\n-------------------------------------------------------------------")
print("SSE Loss min          :", loss_min, "@ epoch", epoch_min)
print ("-------------------------------------------------------------------")


for hand in test_set:
    scaled_input = [rank * 100 for rank in hand]
    predicted, hidden = forward_pass(scaled_input)
    print("\nHand                  :", hand)
    print("Prediction            :", predicted)
    
    min_val = min(predicted)
    shifted_predicted = [x - min_val for x in predicted]
    confidence = max(shifted_predicted) * 100 // sum(shifted_predicted)
    
    hand_types = ["High Card","Pair","Two Pair","Three of a Kind", "Straight",
    "Flush","Full House","Four of a Kind","Straight Flush"
    ]
    max_val = max(predicted)

    if predicted.count(max_val) == 1:
        hand_index = predicted.index(max_val)
        hand_name = hand_types[hand_index]
    else:
        hand_name = "Uncertain prediction (tie)"
        
    print("Predicted Hand        :", hand_name, ", confidence" , confidence, "%")
