// Simulated includes (placeholders for your environment)
include("io.asc");
include("math.asc");

// Input layer
var i = 0; var j = 0; var k = 0
var nr_input_cases = 1
var input_cases = [[1,1,3,4,5]];
var nr_neurons0 = 5

// weights1: cols = nr_neurons0, rows = nr_neurons1
// biases1 = nr_neurons1
// outputs1 = nr_neurons1

// weights1: cols = nr_neurons1, rows = nr_neurons2
// biases1 = nr_neurons2
// outputs1 = nr_neurons2

//-----------------------------------------------------------------------------
// Hidden layer
var nr_neurons1 = 10;
var weights1 = [
    [4, 0, 4, -5, -2],
    [2, -5, 1, 3, 1],
    [-2, 2, -4, -5, 0],
    [-4, -4, 1, 3, -3],
    [-4, -3, 0, 4, -3],
    [-1, -3, 1, 0, 4],
    [-3, -2, -3, 2, 3],
    [-5, -5, 1, -5, 1],
    [1, 3, -5, -4, 6],
    [5, -3, 0, -2, 2],
];
var biases1 = [-1, -2, 1, -1, -3, -4, 2, 3, 1, -3];

// Output layer
var nr_neurons2 = 6;
var weights2 = [
    [-3, -2, -3, -1, 3, -2, 3, 5, -1, 1],
    [0, 3, 2, -2, -1, -3, -3, -4, -1, 0],
    [1, -3, 2, 0, 2, -5, -3, -3, -4, -1],
    [1, 1, -3, 4, -1, 0, -4, -3, -4, -3],
    [-2, -3, 5, 1, -3, 2, -1, -3, -4, 3],
    [1, -2, 1, 4, 2, 0, 1, -2, -1, 1],
    [3, 3, -1, 2, -2, -3, 0, 2, -1, 3],
    [-2, -6, 5, 3, 0, 0, 2, -1, 1, 5],
    [2, -1, -5, -5, -4, -1, 0, -1, 1, 0],
];
var biases2 = [-5, 2, -1, 0, -3, 2, -7, 0, 2];

//-----------------------------------------------------------------------------
var outputs1 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
var outputs2 = [0, 0, 0, 0, 0, 0];


// Simple step activation function: returns 1 if input > 0, else 0
function step (step_input) {
  var step_output=0
  step_output= step_input > 0 ? step_input : 0;
  return step_output
}

// relu activation function: returns input if input > 0, else 0
function relu (relu_input) {
  var relu_output = 0;
  relu_output = relu_input > 0 ? relu_input : 0;
  return relu_output;
}

// Neuron network
function run_network(index) {
	var neuron_sum = 0;

	// --- Hidden Layer: Compute outputs1 ---
	for (j = 0; j < nr_neurons1; j++) { // each hidden neuron
		neuron_sum = 0;
		
	    for (k = 0; k < nr_neurons0; k++) { // each input
	      neuron_sum += weights1[j][k] * input_cases[index][k];
	    }
	    neuron_sum += biases1[j];
	    outputs1[j] = relu(neuron_sum);
		console.log ("L1, N", j, ": ", outputs1[j])
	}
	console.log ("")
	
	// --- Output Layer: Compute outputs2 ---
	for (j = 0; j < nr_neurons2; j++) { // each output neuron
	    neuron_sum = 0;
	    for (k = 0; k < nr_neurons1; k++) { // each input
	      neuron_sum += weights2[j][k] * outputs1[k];
	    }
	    neuron_sum += biases2[j];
	    outputs2[j] = relu(neuron_sum);
		console.log ("L2, N", j, ": ", outputs2[j])
	}
}

// Main Code ------------------------------------------------------------------
for (i = 0; i < nr_input_cases ; i++) {
	// Inputs
	console.log ("Input #", i)
 	for (j = 0; j < nr_neurons0; j++) {
		console.lognumber (input_cases[i][j]);
		console.logchar (",")
		}
	console.log ("")
	console.log ("")

	// Run network
	run_network(i)
	console.log ("")
	
	// Outputs
	console.log ("Outputs: hand likeliness.")
	for (j = 0; j < nr_neurons2; j++) {
		console.lognumber (outputs2[j]);
		console.logchar (",")
	}
	console.log ("")
}

