import sys
from pathlib import Path
import config
import translator as translator_module
import utils as utils_module
from utils import process_non_js, find_missing_routines
from translator import translate_to_assembly

def reset_compiler_state():
    config.nodes_code.clear()
    config.include_filenames_list.clear()
    config.function_declarations.clear()
    config.variable_declarations.clear()
    config.variable_type_list.clear()
    config.constant_type_list.clear()
    config.object_type_list.clear()
    config.array_type_list.clear()
    config.matrix_type_list.clear()
    config.string_type_list.clear()
    config.break_label_stack.clear()
    config.update_label_stack.clear()
    config.label_count = 0
    config.update_label = ""
    config.function_end_tag = "# EOF TAG"
    config.function_exit_tag = ""
    config.garbage_address_current = 0

    translator_module.function_end_tag = config.function_end_tag
    translator_module.function_exit_tag = config.function_exit_tag
    translator_module.update_label = config.update_label

    utils_module.clear_errors()

def resolve_include(filename, input_file):
    candidates = [
        Path(filename),
        Path(input_file).resolve().parent / filename,
        Path(__file__).resolve().parent / filename,
    ]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    raise FileNotFoundError(filename)

def main(input_file, output_file):
    reset_compiler_state()
    
    # variables----------------------------------------------------------------
    full_code = []
    
    # Read JavaScript code
    with open(input_file, "r", encoding="utf-8") as file:
        input_code = file.read()

    # process non-JS code
    processed_code = process_non_js(input_code)

    # Translate JavaScript to assembly
    nodes_code, variable_declarations, include_filenames_list = translate_to_assembly(processed_code)
    
    # assembly code build -------------------------------------------------------
    # compiler info
    full_code.append(f"; Generated with JAvaScript to ASSembly COmpiler, JASSCO v0. Boria Labs 2025.")
    
    # directives ------------------------------------------------------------------------------
    full_code.append("; Directives -------------------------------------------------")
    full_code.append(f"        org {config.initial_address}               ; initial code address")
    full_code.append(f"        jp mai_cod              ; jumps to main code")
    
    # variable declarations -------------------------------------------------------------------
    full_code.append("\n; Variable declarations --------------------------------------")
    # auxiliary stack
    full_code.append(f"        sta_ck2 defw {config.stack2_address}      ; auxiliary stack address") 

    if variable_declarations:
        full_code.append("\n".join(variable_declarations)) 
    
    # Include files ---------------------------------------------------------------------------
    full_code.append(f"\n; Include files ----------------------------------------------")
    for filename in include_filenames_list:
        include_path = resolve_include(filename, input_file)
        with open(include_path, 'r') as file:
            content = file.read()
            full_code.append(content)
        
    # program code ----------------------------------------------------------------------------
    full_code.append("\n; Program code -----------------------------------------------")
    
    # find end of last function in nodes_code
    count=0
    last_function_line = -1
    for i, line in enumerate(nodes_code):
        if config.function_end_tag in line:
            if last_function_line != -1:
                nodes_code[last_function_line] = ""
            count += 1
            last_function_line = i  # Update to the index of the last occurrence
    
    # Replace the last occurrence with the replace_string (if any was found)
    if last_function_line != -1:
        nodes_code[last_function_line] = "mai_cod                         ; main code"

    for line in nodes_code:
        full_code.append(line)
        
    # end section -----------------------------------------------------------------------------
    full_code.append ("        ret                     ; end of code")
    
    # -----------------------------------------------------------------------------------------
    # check all calls in assembly and spot missing libraries
    missing_routines = find_missing_routines(full_code)
    if missing_routines:
        raise RuntimeError(f"Missing assembly routines: {', '.join(missing_routines)}")

    if utils_module.compiler_errors:
        raise RuntimeError(
            "Compilation failed with errors:\n" + "\n".join(utils_module.compiler_errors)
        )

    # print full code in console
    print("\n".join(full_code))
    
    # write the assembly code to output file
    with open(output_file, "w", encoding="utf-8") as file:
        file.write("\n".join(full_code))

# ---------------------------------------------------------------------------------------------
if __name__ == "__main__":
    # Set default input and output file names
    input_file = "input.js"
    output_file = "output.asm"

    # Check if positional arguments are provided
    if len(sys.argv) > 1:
        input_file = sys.argv[1]  # First argument is input file
    if len(sys.argv) > 2:
        output_file = sys.argv[2]  # Second argument is output file

    # Call main function with the determined files
    main(input_file, output_file)
